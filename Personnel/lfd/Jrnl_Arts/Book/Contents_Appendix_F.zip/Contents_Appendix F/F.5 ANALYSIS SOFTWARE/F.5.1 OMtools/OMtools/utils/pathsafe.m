function out = pathsafe(in)

out = strrep(in,' ','\ ');