function warnbeep

beep;pause(0.33);beep