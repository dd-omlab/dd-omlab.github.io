% ezlink: makes it easier to add URL and matlab: links & text.
%
