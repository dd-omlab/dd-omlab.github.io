for ii = 51:100
   vv=(100*(ii-1):(100*ii)-1)+1;
   aa=char(vv);
   fprintf('%d: %s\n',vv(1),aa);
end