function errorbeep

beep;pause(0.33);beep;pause(0.33);beep