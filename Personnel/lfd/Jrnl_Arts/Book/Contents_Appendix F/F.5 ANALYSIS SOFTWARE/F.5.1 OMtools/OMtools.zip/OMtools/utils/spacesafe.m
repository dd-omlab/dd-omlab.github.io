function out = spacesafe(in)

out = ['' in ''];