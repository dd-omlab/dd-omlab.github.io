function nofun
fprintf('You''re no fun anymore!\n');
keyboard
end % function