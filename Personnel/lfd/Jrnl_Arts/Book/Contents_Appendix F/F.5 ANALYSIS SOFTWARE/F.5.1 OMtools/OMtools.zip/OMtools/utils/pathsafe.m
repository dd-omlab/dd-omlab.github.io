function out = pathsafe(in)

out = strrep(in,' ','\ ');
%out = ['' in ''];