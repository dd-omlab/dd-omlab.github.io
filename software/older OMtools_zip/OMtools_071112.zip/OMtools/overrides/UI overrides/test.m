function test()
[fn,pn] = uigetfile('*.mat' , 'Load an existing model parameter file:');
%[fn,pn] = uigetfile('Load an existing model parameter file:', '*.mat');