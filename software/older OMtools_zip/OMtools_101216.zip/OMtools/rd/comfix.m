
function out = comfix(in);

[disc1, rem] = strtok(in, ' ');
[disc2, out] = strtok(rem, ' ');