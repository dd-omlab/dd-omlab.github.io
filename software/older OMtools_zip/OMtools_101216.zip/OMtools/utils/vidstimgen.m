function vidstimgen(inp1)

% determine
% screen resolution, dimensions, distance
% stim sequence: time, position, size, color

circColor = 'w';
%tgt_rad = 1.0;
%bg_color = 'k';
scale = 0.75;

old_dir=pwd;

% right now i am saving each frame as its own image file because I finally
% figured out how to force the image to be saved with the EXACT pixel
% dimensions i desire. If I can make that happen wuing MATLAB's 
[filename, pathname] = uiputfile( {'*.jpg';'*.png';'*.pdf';'*.tiff';'*.bmp'}, ... 
    'Save the stimulus image(s) as: ');
[filename, ext] = strtok(filename,'.');
cd(pathname); 
mkdir(filename)
cd(filename)

stim_mov = VideoWriter([filename]);
stim_mov.FrameRate = 0.2;
stim_mov.Quality = 100;

% what screens are available?
temp = get(0);
mon_pos = temp.MonitorPositions;
[numscreens, ~] = size(mon_pos);
disp('Local screen dimensions')
for j=1:numscreens
    swid = mon_pos(j, 3);
    shgt = mon_pos(j, 4);
    disp( ['Screen ' num2str(j) ': ' num2str(swid) ' by ' num2str(shgt)] )
end

% can select monitor for target image size when calling this program from
% the command line. 
if nargin == 0,
   tgtmon = 1;
else
    tgtmon = inp1;
end

% We need to know the target monitor's physical and display dimensions.
% We also need to decide how far the subject will sit from the monitor.
% These values will let us calculate how many degrees the monitor spans and
% how many pixels equal one degree.

% from what distance will the subject view stimulus?
dist_to_subj = 550; % MILLIMETERS
        
% measure the monitor's actual displayable screen size in MILLIMETERS.
switch tgtmon 
    case 1        
        % Apple Cinema HD dimensions.
        scr_pix_wid = 1920; scr_pix_hgt = 1280;  % PIXELS
        scr_phys_wid = 490; scr_phys_hgt = 310;  % MILLIMETERS
    case 2
        % Monoprice 28" 4K
        scr_pix_wid = 2560; scr_pix_hgt = 1440;  % PIXELS
        scr_phys_wid = 620; scr_phys_hgt = 340;  % MILLIMETERS       
    case 3
        % Retina MacBook Pro 15"
        scr_pix_wid = 1440; scr_pix_hgt = 900;  % PIXELS
        scr_phys_wid = 331; scr_phys_hgt = 208;  % MILLIMETERS       
    case 4
        % iPad Air, when MIRRORING rMBP15 (ignoring pixel doubling)
        scr_pix_wid = 1440; scr_pix_hgt = 900;  % PIXELS
        scr_phys_wid = 197; scr_phys_hgt = 113;  % MILLIMETERS       
    case 5
        % iPad Air, native (ignoring pixel doubling)
        scr_pix_wid = 1024; scr_pix_hgt = 768;  % PIXELS
        scr_phys_wid = 197; scr_phys_hgt = 148;  % MILLIMETERS       
        
    otherwise
end

%aspect = scr_pix_wid / scr_pix_hgt;
scr_pix_wid = scale * scr_pix_wid;
scr_pix_hgt = scale * scr_pix_hgt;

% geometry is our friend.
% at distance D from the screen, what are dimensions in DEGREES?
temp = atan(scr_phys_wid / dist_to_subj); % in RADIANS
half_alpha_hor = temp*180/pi; % degrees
temp = atan(scr_phys_hgt / dist_to_subj); % in RADIANS
half_alpha_vrt = temp*180/pi; % degrees

hpix_per_deg = scr_pix_wid / (2 * half_alpha_hor);
vpix_per_deg = scr_pix_hgt / (2 * half_alpha_vrt);

% how wide is our stimulus?
stim_wid = 0.5; % DEGREES
stim_hgt = 0.5; % DEGREES

stim_wid = stim_wid * hpix_per_deg; % in PIXELS
stim_hgt = stim_hgt * vpix_per_deg; % in PIXELS

% walk the sequence to generate movie frames
% [x_pos, y_pos] in DEGREES, duration in SECONDS
target{1}.x =   0; target{1}.y =    0; target{1}.dur = 5.0;
target{2}.x =   5; target{2}.y =    0; target{2}.dur = 5.0;
target{3}.x =  -5; target{3}.y =    0; target{3}.dur = 5.0;
target{4}.x =  10; target{4}.y =    0; target{4}.dur = 5.0;
target{5}.x = -10; target{5}.y =    0; target{5}.dur = 5.0;
target{6}.x =  15; target{6}.y =    0; target{6}.dur = 5.0;
target{7}.x = -15; target{7}.y =    0; target{7}.dur = 5.0;
target{8}.x =   0; target{8}.y =    0; target{8}.dur = 5.0;
target{9}.x =   0; target{9}.y =   10; target{9}.dur = 5.0;
target{10}.x =  0; target{10}.y = -10; target{10}.dur = 5.0;
target{11}.x =  0; target{11}.y =   0; target{11}.dur = 5.0;

fig=figure; box off
hold on
set(fig, 'color','k', 'menubar','none')
set(fig,'Position',[0,0, scr_pix_wid, scr_pix_hgt])
set(fig,'Units','normalized')
%set(fig,'Position',[(1-scale)/2, (1-scale)/2, scale, scale])
set(fig,'PaperPositionMode','auto')
set(fig,'InvertHardCopy', 'off');
set(fig,'Units','pixels')

ax = gca;
set(ax,'Units','normalized')
set(ax,'OuterPosition', [0 0 1 1])
set(ax,'Position', [0 0 1 1])
axis off; axis equal tight
set(ax,'Units','pixels')
set(ax,'Xlim',[-scr_pix_wid/2, scr_pix_wid/2])
set(ax,'Ylim',[-scr_pix_hgt/2, scr_pix_hgt/2])

open(stim_mov)
extend = 1; % 50;
for k = 1:length(target)
    xpos=target{k}.x * hpix_per_deg; ypos=target{k}.y * vpix_per_deg;        
    circHand = circ(stim_wid,stim_hgt,xpos,ypos,circColor);
    pause(0.25)
    for i=1:extend
        temp=((k-1)*extend+i);
        print( [filename '_' num2str(temp) ext], '-djpeg', '-r0' )
        F = getframe;
        writeVideo(stim_mov, F);
    end
    
    %saveas(fig, [filename '_' num2str(k) ext] )
    delete(circHand)
end

cd(old_dir)
close(stim_mov)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function circHand = circ( xrad,yrad,xcenter,ycenter,circColor )

vect = -0.1:0.1:2*pi;
x=xrad*cos(vect) + xcenter;
y=yrad*sin(vect) + ycenter;

circHand = fill(x,y,[1 1 1]);
set(circHand,'facecolor',circColor);
%linHand  = line(x,y);
%set(linHand,'color',circColor);