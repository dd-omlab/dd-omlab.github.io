function out = safepath(in)


%temp = strrep(in, ' ', '\ ');

out = ['''' in ''''];