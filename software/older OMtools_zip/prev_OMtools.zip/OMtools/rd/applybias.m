% applybias.m:  
% Apply the offset and scaling factor(s) found by 'getbias' to the data being loaded.

% written by: Jonathan Jacobs
%             February 2004  (last mod: 01/25/04)

% clear the eyelink blinks
%newdata=deblink(newdata);  %% BIG problem with deblink is that
                            %% many MATLAB routines choke on NaNs.  Dumb.
                            %% So-so sol'n: use 'zeronans' and 'renanify' on
                            %% either side of troubled routines.

% we now know the channel names, so we can
% read in the unfolding file, if it exists, and apply the fixes.
unfold 

if ~doScaling
   return
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we now have the data and the needed offset/scaling factors.
% so let's do the offset and scaling
rectype = lower(rectype);
for i = 1:dat_cols
   if lower(rectype(1)) == 'c' | lower(rectype(1)) == 's'
      newdata(:,i) = newdata(:,i) - z_adj(i);
      newdata(:,i) = newdata(:,i) / c_scale(i);     

    elseif lower(rectype(1)) == 'r'
      newdata(:,i) = sincorrect( newdata(:,i), r_offset(i), r_scale(i), r_calpt(i) );

    elseif lower(rectype(1)) == 'i' | lower(rectype(1)) == 'v'
      if numcalpts == 1
         % standard calibration
         newdata(:,i) = adj(newdata(:,i), z_adj(i),...
                            maxcalpt(i,:), max_adj(:,i), mincalpt(i,:), min_adj(:,i));
       else
         % extended calibration
         newdata(:,i) = adj(newdata(:,i), z_adj(i),...
                            maxcalpt(i,:), max_adj(:,i), mincalpt(i,:) ,min_adj(:,i));
      end
   end
end

%return  % back to RD.M for the grand finale...
