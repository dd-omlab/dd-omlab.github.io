%ev.m: Eye Position axis labels
ylabel( 'Eye Velocity (�/sec)' )