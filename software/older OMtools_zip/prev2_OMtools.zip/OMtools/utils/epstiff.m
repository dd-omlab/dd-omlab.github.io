% epstiff.m: save a figure as Encapsulated Postscript with a high-quality TIFF preview that won't
% cause MS Word 2004 to vomit and die, the way ones with MATLAB-generated TIFF previews will.
% Why should you care?  Because without any preview, an EPS figure will not show up in Word, which
% is nearly useless.  An EPS figure with a high-quality TIFF preview will look good on the
% screen and when printed, rather than being all fuzzy and pixelated.  
% Reviewers like figures that don't look like crap.  Don't piss them off.
%
% This program requires that 'epstool' be installed.  For Mac OS X users, the easiest way to do 
% this is to use the MacPorts package manager 'Porticus' (http://porticus.alittledrop.com/), once
% you have downloaded and installed MacPorts (http://trac.macports.org/browser/downloads/).
% Finally, note that you must have Apple's free XCode developer tools installed.
%
% After installing epstool, you should verify that these lines have been added to your 
% '.profile' file in your home directory (~/.profile):
% export PATH=$PATH:/opt/local/bin
% export DISPLAY=:0.0 
% (see http://www.tech-recipes.com/rx/2618/os_x_easily_edit_hidden_configuration_files_with_textedit
% for help doing this.)

% Written by:  Jonathan Jacobs
%              September 2008  last mod 09/29/08

function epstiff

compy = computer;
if ~strcmp(compy, 'MAC')
	disp('''epstiff'' was written for Mac OS X.')
	return
end

if isempty( get(0,'CurrentFigure') )
	disp('''epstiff'' requires an open figure to run.')
	return
end

% check to see if MacPorts directory exists
if ~isdir('/opt/local/bin')
   disp('You have not installed MacPorts.  Type ''help epstiff'' for more information.')
   return
end

% if it's there, but not already on the PATH, add it.
% http://www.mathworks.de/matlabcentral/newsreader/view_thread/171203
initpath=getenv('PATH');
if isempty( findstr(initpath, 'opt/local/bin') )
	setenv('PATH', [initpath ':/opt/local/bin']);
end

% Now see if epstool was installed.
epstool_installed = exist('/opt/local/bin/epstool');
if epstool_installed ~= 2
   disp('You have not installed epstool.  Type ''help esptiff'' for more information.')
   return
end

[fn, pn] = uiputfile('*.eps', 'Save the figure as:');
if fn == 0
	disp('Canceled.')
	return
end

% make sure that file name ends in '.eps'
[tok, rem] = strtok(fn, '.');
fn = [tok '.eps'];   

% FINALLY, the actual work.  Save the file as an .eps, and then call epstool
% to add a high-quality TIFF preview and overwrite the original file.
eval( ['print -depsc2 ' [pn fn] ]) 
eval( ['!/opt/local/bin/epstool -t6p --device bmpgray --dpi 300 ' [pn fn] ' ' [pn fn] ] )
